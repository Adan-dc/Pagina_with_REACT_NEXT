import { Suspense } from "react";
import Link from "next/link";

type ProductoOrden = {
  id: string;
  nombre: string;
  cantidad: number;
  precio: number;
};

type Orden = {
  id: string;
  codigo: string;
  fecha: string;
  cliente: string;
  direccion: string;
  comuna: string;
  productos: ProductoOrden[];
};

async function DetalleBoleta({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const respuesta = await fetch(
    `http://localhost:3001/ordenes/${id}`,
    { cache: "no-store" }
  );

  if (!respuesta.ok) {
    return <p>No se encontró la boleta.</p>;
  }

  const orden: Orden = await respuesta.json();

  let total = 0;

  orden.productos.forEach((producto) => {
    total += producto.precio * producto.cantidad;
  });

  return (
    <main className="container py-4">
      <h1>Boleta #{orden.codigo}</h1>

      <div className="card mt-4 boleta-admin">
        <div className="card-body">
          <p>Cliente: {orden.cliente}</p>
          <p>Fecha: {orden.fecha}</p>
          <p>Dirección: {orden.direccion}, {orden.comuna}</p>

          <h2 className="h5">Productos</h2>

          <ul className="list-group mb-3">
            {orden.productos.map((producto) => (
              <li className="list-group-item" key={producto.id}>
                {producto.nombre} - {producto.cantidad} x
                ${producto.precio.toLocaleString("es-CL")}
              </li>
            ))}
          </ul>

          <p className="fw-bold">
            Total: ${total.toLocaleString("es-CL")}
          </p>

          <Link href="/admin/ordenes" className="btn btn-secondary">
            Volver a órdenes
          </Link>
        </div>
      </div>
    </main>
    
  );
  
}
export default function MostrarBoleta({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  return (
    <Suspense fallback={<p>Cargando boleta...</p>}>
      <DetalleBoleta params={params} />
    </Suspense>
  );
}
