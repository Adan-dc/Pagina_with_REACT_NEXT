"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
type ProductoOrden = {
  id: string;
  nombre: string;
  cantidad: number;
  precio: number;
};

type Orden = {
  id: string;
  codigo: string;
  fecha: string;
  cliente: string;
  direccion: string;
  comuna: string;
  productos: ProductoOrden[];
};

export default function Ordenes() {
  const [ordenes, setOrdenes] = useState<Orden[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    async function obtenerOrdenes() {
      try {
        const respuesta = await fetch("http://localhost:3001/ordenes");

        if (!respuesta.ok) {
          throw new Error("No se pudieron cargar las órdenes");
        }

        const datos: Orden[] = await respuesta.json();
        setOrdenes(datos);
      } catch {
        setError("No se pudieron obtener las órdenes de la API.");
      }
    }

    obtenerOrdenes();
  }, []);

  function calcularTotal(orden: Orden) {
    let total = 0;

    orden.productos.forEach((producto) => {
      total += producto.precio * producto.cantidad;
    });

    return total;
  }

  return (
    <main className="container py-4 Ordenes">
      <h1>Órdenes y boletas</h1>
      <p>Aquí podrás revisar las compras realizadas.</p>

      {error && <p className="alert alert-danger">{error}</p>}

      <div className="table-responsive">
        <table className="table table-striped">
          <thead>
            <tr>
              <th>ID</th>
              <th>Código</th>
              <th>Fecha</th>
              <th>Monto</th>
              <th>Comuna</th>
              <th>Acciones</th>
            </tr>
          </thead>

          <tbody>
            {ordenes.length === 0 && (
              <tr>
                <td colSpan={6} className="text-center">
                  No hay órdenes registradas.
                </td>
              </tr>
            )}

            {ordenes.map((orden) => (
              <tr key={orden.id}>
                <td>{orden.id}</td>
                <td>{orden.codigo}</td>
                <td>{orden.fecha}</td>
                <td>${calcularTotal(orden).toLocaleString("es-CL")}</td>
                <td>{orden.comuna}</td>
                <td>
                  <Link
                    href={`/admin/ordenes/${orden.id}`}
                    className="btn btn-primary btn-sm"
                  >
                    Ver boleta
                </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </main>
  );
}
